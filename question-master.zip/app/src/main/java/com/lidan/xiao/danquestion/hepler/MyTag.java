package com.lidan.xiao.danquestion.hepler;

public class MyTag  {
    public final static int QUE=1;
    public final static int COLLECT=2;
    public final static int WRONG=3;
    public final static int CARD=4;
}
